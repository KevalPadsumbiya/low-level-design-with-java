package com.example.javalld.parkinglot.model;

public class Truck extends Vehicle {
    public Truck(String numberPlate) {
        super(VehicleType.TRUCK, numberPlate);
    }
}
