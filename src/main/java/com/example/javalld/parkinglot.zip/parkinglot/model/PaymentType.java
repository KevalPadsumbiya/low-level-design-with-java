package com.example.javalld.parkinglot.model;

public enum PaymentType {
    CREDIT_CARD,
    UPI
}
