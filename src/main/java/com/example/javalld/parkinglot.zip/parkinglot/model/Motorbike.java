package com.example.javalld.parkinglot.model;

public class Motorbike extends Vehicle {
    public Motorbike(String numberPlate) {
        super(VehicleType.MOTORBIKE, numberPlate);
    }
}
