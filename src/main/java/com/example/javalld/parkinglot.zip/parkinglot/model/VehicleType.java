package com.example.javalld.parkinglot.model;

public enum VehicleType {
    MOTORBIKE,
    CAR,
    VAN,
    TRUCK
}
