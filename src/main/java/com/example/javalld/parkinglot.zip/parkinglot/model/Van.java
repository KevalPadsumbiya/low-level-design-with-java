package com.example.javalld.parkinglot.model;

public class Van extends Vehicle {
    public Van(String numberPlate) {
        super(VehicleType.VAN, numberPlate);
    }
}
