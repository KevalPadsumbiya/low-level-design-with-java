package com.example.javalld.parkinglot.exceptions;

public class ParkingLotFullException extends Exception {
}
