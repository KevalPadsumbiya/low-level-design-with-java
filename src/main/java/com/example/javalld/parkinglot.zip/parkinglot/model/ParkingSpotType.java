package com.example.javalld.parkinglot.model;

public enum ParkingSpotType {
    HANDICAPPED,
    TWO_WHEELER,
    COMPACT,
    LARGE
}
