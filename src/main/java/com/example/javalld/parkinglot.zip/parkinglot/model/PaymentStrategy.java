package com.example.javalld.parkinglot.model;

public interface PaymentStrategy {
    public void pay(Double amount);
}
