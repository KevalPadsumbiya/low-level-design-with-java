package com.example.javalld.parkinglot.model;

public class Car extends Vehicle {
    public Car(String numberPlate) {
        super(VehicleType.CAR, numberPlate);
    }
}
