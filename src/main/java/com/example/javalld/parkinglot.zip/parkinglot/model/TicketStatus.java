package com.example.javalld.parkinglot.model;

public enum TicketStatus {
    ACTIVE,
    PAID,
    LOST
}
